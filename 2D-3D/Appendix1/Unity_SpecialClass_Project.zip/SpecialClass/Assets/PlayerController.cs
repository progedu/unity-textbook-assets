﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    public float jumpPower = 5f; //ジャンプ力

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0)) //左クリックを押したら
        {   //Y軸方向にジャンプします
            this.GetComponent<Rigidbody>().velocity = new Vector3(0, jumpPower, 0);
        }
    }
}
