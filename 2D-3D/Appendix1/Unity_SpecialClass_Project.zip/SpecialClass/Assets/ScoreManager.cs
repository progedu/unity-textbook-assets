﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{

    public static int score; // スコアの変数
    private Text scoreText; // スコアのテキスト

    // Start is called before the first frame update
    void Start()
    {
        score = 0; // スコアの値を0で初期化
        scoreText = GetComponent<Text>(); // テキストコンポーネントを参照
    }

    // Update is called once per frame
    void Update()
    {
        scoreText.text = "Score: " + score.ToString(); //スコアのテキスト情報を更新
    }
}

