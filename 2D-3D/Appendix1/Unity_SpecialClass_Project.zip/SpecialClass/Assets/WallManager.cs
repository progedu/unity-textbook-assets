﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //シーンを管理するパッケージを追加

public class WallManager : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)  //オブジェクトが通過したら呼ばれるメソッド
    {
        if (other.tag == "Player") //通過したオブジェクトのTagが"Player"だったら
        {
            Invoke("GameReload", 2.0f); //GameReloadメソッドを2秒後に呼ぶ
            Destroy(other.gameObject, 1.0f); //当たってきたオブジェクト= "Player"を消す
        }
    }

    void GameReload() // シーンを再ロードするメソッド
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); //現在のシーンを再ロードします。
    }
}

