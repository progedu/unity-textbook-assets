﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    public GameObject wallPrefab;　//Wallを追加
    public float interval = 2.0f; // Wallが生成されるインターバル
    public float range = 2.0f; //Y軸をランダムに降る

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("CreateWalls", interval, interval); //intervalごとにCreateWallsメソッドを呼びます
    }

    // Update is called once per frame
    void CreateWalls()
    {
        transform.position = new Vector3(transform.position.x, Random.Range(-range, range), transform.position.z); // Position Yの値に-range〜rangeの間で値を入れて位置をランダム化する
        Instantiate(wallPrefab, transform.position, transform.rotation); //Wallを生成します
    }
}

