﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScorePoint : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    private void OnTriggerEnter(Collider other) //オブジェクトが通過したら呼ばれる
    {
        if (other.tag == "Player") // 通過したオブジェクトのTagがPlayerだったら
        {
            ScoreManager.score++; //スコアを加算します
        }
    }
}
