﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallMove : MonoBehaviour
{
    public Vector3 moveDirection = new Vector3(-3f, 0, 0); //壁の移動方向

    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, 10.0f); // 壁が生成されて10秒後に削除
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(moveDirection.x * Time.deltaTime, moveDirection.y, moveDirection.z); //実際に移動する
    }
}

